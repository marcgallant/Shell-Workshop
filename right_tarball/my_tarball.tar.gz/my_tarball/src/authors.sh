#!/bin/sh

echo "marc.gallant" > AUTHORS
chmod 640 AUTHORS
